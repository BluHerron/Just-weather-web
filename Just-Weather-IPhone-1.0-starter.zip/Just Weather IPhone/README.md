# Just Weather IPhone

Native SwiftUI rebuild of the proven Just Weather Roku app.

## Requirements
- Xcode 26 or later
- iOS 26 SDK or later for App Store submission
- macOS compatible with the installed Xcode

## First run
1. Open `Just Weather IPhone.xcodeproj` in Xcode.
2. Select an iPhone Simulator or your connected iPhone.
3. Choose your Apple Developer Team under Signing & Capabilities.
4. Build and run.

The app persists favorites, selected location, units, radar range/mode, clock, wind units, and dimming settings with UserDefaults.

## Current feature set
- Current weather and 7-day forecast
- Searchable locations and current-location support
- Persistent favorites
- Radar screen foundation
- Nearest NOAA weather radio search using WXIndex
- Internet radio using Radio Browser
- Persistent settings
- Native iPhone tab navigation

## Notes
The Roku implementation remains the functional reference. This iPhone project is intentionally native rather than a BrightScript/UI port. Physical-device testing and App Store signing must be done in Xcode on a Mac.
