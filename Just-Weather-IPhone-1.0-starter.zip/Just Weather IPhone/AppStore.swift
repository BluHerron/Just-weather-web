import Foundation
import CoreLocation
import AVFoundation
import MapKit

@MainActor
final class AppStore: NSObject, ObservableObject {
    @Published var selectedLocation: WeatherLocation?
    @Published var favorites: [WeatherLocation] = []
    @Published var weather: WeatherSnapshot?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var units: WeatherUnits = .fahrenheit
    @Published var radarEnabled = true
    @Published var radarMiles = 25
    @Published var clock24 = false
    @Published var windKmh = false
    @Published var dimEnabled = true
    @Published var noaaStations: [NOAAStation] = []
    @Published var radioStations: [RadioStation] = []
    @Published var radioCategory = ""
    @Published var isFindingNOAA = false
    @Published var isFindingRadio = false
    @Published var radioPlaying = false

    private let defaults = UserDefaults.standard
    private let locationManager = CLLocationManager()
    private let weatherService = WeatherService()
    private var player: AVPlayer?

    override init() {
        super.init()
        locationManager.delegate = self
        loadPreferences()
    }

    func start() async {
        if selectedLocation == nil {
            locationManager.requestWhenInUseAuthorization()
            locationManager.requestLocation()
        }
        if let selectedLocation {
            await refresh(location: selectedLocation)
        }
    }

    func refresh(location: WeatherLocation? = nil) async {
        guard let location = location ?? selectedLocation else { return }
        selectedLocation = location
        isLoading = true
        errorMessage = nil
        do {
            weather = try await weatherService.fetchWeather(for: location, units: units, windKmh: windKmh)
            saveSelectedLocation()
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    func addFavorite(_ location: WeatherLocation) {
        if let index = favorites.firstIndex(where: { $0.name.caseInsensitiveCompare(location.name) == .orderedSame }) {
            favorites[index] = location
        } else {
            favorites.append(location)
        }
        saveFavorites()
    }

    func removeFavorite(_ location: WeatherLocation) {
        favorites.removeAll { $0.id == location.id || $0.name.caseInsensitiveCompare(location.name) == .orderedSame }
        saveFavorites()
    }

    func select(_ location: WeatherLocation) async {
        selectedLocation = location
        saveSelectedLocation()
        await refresh(location: location)
    }

    func searchLocations(_ query: String) async throws -> [WeatherLocation] {
        try await weatherService.searchLocations(query)
    }

    func findNOAA() async {
        guard let location = selectedLocation else { return }
        isFindingNOAA = true
        defer { isFindingNOAA = false }
        do {
            noaaStations = try await weatherService.findNOAAStations(near: location)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func findRadio(category: String) async {
        guard let location = selectedLocation else { return }
        isFindingRadio = true
        radioCategory = category
        defer { isFindingRadio = false }
        do {
            radioStations = try await weatherService.findRadioStations(category: category, near: location)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func play(url: String) {
        guard let u = URL(string: url) else { return }
        player = AVPlayer(url: u)
        player?.play()
        radioPlaying = true
    }

    func stopRadio() {
        player?.pause()
        player = nil
        radioPlaying = false
    }

    func savePreferences() {
        defaults.set(units.rawValue, forKey: "units")
        defaults.set(radarEnabled, forKey: "radarEnabled")
        defaults.set(radarMiles, forKey: "radarMiles")
        defaults.set(clock24, forKey: "clock24")
        defaults.set(windKmh, forKey: "windKmh")
        defaults.set(dimEnabled, forKey: "dimEnabled")
        saveFavorites()
        saveSelectedLocation()
    }

    private func loadPreferences() {
        if let raw = defaults.string(forKey: "units"), let value = WeatherUnits(rawValue: raw) { units = value }
        radarEnabled = defaults.object(forKey: "radarEnabled") as? Bool ?? true
        radarMiles = defaults.object(forKey: "radarMiles") as? Int ?? 25
        clock24 = defaults.object(forKey: "clock24") as? Bool ?? false
        windKmh = defaults.object(forKey: "windKmh") as? Bool ?? false
        dimEnabled = defaults.object(forKey: "dimEnabled") as? Bool ?? true
        if let data = defaults.data(forKey: "favorites"), let saved = try? JSONDecoder().decode([WeatherLocation].self, from: data) { favorites = saved }
        if let data = defaults.data(forKey: "selectedLocation"), let saved = try? JSONDecoder().decode(WeatherLocation.self, from: data) { selectedLocation = saved }
    }

    private func saveFavorites() {
        if let data = try? JSONEncoder().encode(favorites) { defaults.set(data, forKey: "favorites") }
    }

    private func saveSelectedLocation() {
        guard let selectedLocation, let data = try? JSONEncoder().encode(selectedLocation) else { return }
        defaults.set(data, forKey: "selectedLocation")
    }
}

extension AppStore: CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse { manager.requestLocation() }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let last = locations.last, selectedLocation == nil else { return }
        Task { @MainActor in
            let place = try? await CLGeocoder().reverseGeocodeLocation(last).first
            let city = place?.locality ?? place?.administrativeArea ?? "Current Location"
            let location = WeatherLocation(name: city, latitude: last.coordinate.latitude, longitude: last.coordinate.longitude)
            await select(location)
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // Saved locations remain fully usable when location permission is denied.
    }
}
