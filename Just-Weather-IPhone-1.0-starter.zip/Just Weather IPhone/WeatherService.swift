import Foundation

struct WeatherService {
    private let session: URLSession = .shared

    func searchLocations(_ query: String) async throws -> [WeatherLocation] {
        let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let url = URL(string: "https://geocoding-api.open-meteo.com/v1/search?count=10&language=en&format=json&name=\(encoded)")!
        let (data, response) = try await session.data(from: url)
        try validate(response)
        let decoded = try JSONDecoder().decode(GeoResponse.self, from: data)
        return decoded.results.map { WeatherLocation(name: [$0.name, $0.admin1].compactMap { $0 }.joined(separator: ", "), latitude: $0.latitude, longitude: $0.longitude) }
    }

    func fetchWeather(for location: WeatherLocation, units: WeatherUnits, windKmh: Bool) async throws -> WeatherSnapshot {
        let temperatureUnit = units == .fahrenheit ? "fahrenheit" : "celsius"
        let windUnit = windKmh ? "kmh" : "mph"
        let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=\(location.latitude)&longitude=\(location.longitude)&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,wind_direction_10m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset&hourly=temperature_2m,precipitation_probability&temperature_unit=\(temperatureUnit)&wind_speed_unit=\(windUnit)&timezone=auto&forecast_days=8")!
        let (data, response) = try await session.data(from: url)
        try validate(response)
        let decoded = try JSONDecoder().decode(OpenMeteoResponse.self, from: data)
        let days = decoded.daily.time.enumerated().compactMap { i, dateString -> ForecastDay? in
            guard let date = ISO8601DateFormatter().date(from: dateString + "T12:00:00Z") else { return nil }
            return ForecastDay(date: date, high: decoded.daily.temperatureMax[i], low: decoded.daily.temperatureMin[i], precipitationProbability: decoded.daily.precipitation[i], condition: condition(decoded.daily.weatherCode[i]))
        }
        let hourly = decoded.hourly.time.enumerated().prefix(24).compactMap { i, dateString -> HourlyPoint? in
            guard let date = ISO8601DateFormatter().date(from: dateString + ":00Z") else { return nil }
            return HourlyPoint(date: date, temperature: decoded.hourly.temperature[i], precipitationProbability: decoded.hourly.precipitation[i])
        }
        return WeatherSnapshot(location: location, temperature: decoded.current.temperature, apparentTemperature: decoded.current.apparentTemperature, humidity: decoded.current.humidity, windSpeed: decoded.current.windSpeed, windDirection: direction(decoded.current.windDirection), condition: condition(decoded.current.weatherCode), days: days, hourly: hourly, updatedAt: Date())
    }

    func findNOAAStations(near location: WeatherLocation) async throws -> [NOAAStation] {
        let url = URL(string: "https://api.wxindex.org/v1/stations/all")!
        let (data, response) = try await session.data(from: url)
        try validate(response)
        let stations = try JSONDecoder().decode([WXStation].self, from: data)
        return stations.compactMap { station in
            guard let lat = station.latitude, let lon = station.longitude else { return nil }
            guard let feed = station.feeds?.first(where: { !($0.stream_url?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ?? true) }), let stream = feed.stream_url else { return nil }
            return NOAAStation(name: "NOAA Weather Radio — \(station.city ?? "Unknown") (\(station.callsign ?? "NOAA"))", callSign: station.callsign ?? "NOAA", city: station.city ?? "Unknown", frequency: station.frequency ?? "", streamURL: stream, distanceMiles: Int(distanceMiles(lat1: location.latitude, lon1: location.longitude, lat2: lat, lon2: lon).rounded()))
        }.sorted { $0.distanceMiles < $1.distanceMiles }.prefix(8).map { $0 }
    }

    func findRadioStations(category: String, near location: WeatherLocation) async throws -> [RadioStation] {
        var urlString: String
        if category == "local-radio" {
            urlString = "https://de1.api.radio-browser.info/json/stations/search?hidebroken=true&geo_lat=\(location.latitude)&geo_long=\(location.longitude)&geo_distance=80467&has_geo_info=true&order=clickcount&reverse=true&limit=10"
        } else {
            let tag = category.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? category
            urlString = "https://de1.api.radio-browser.info/json/stations/search?hidebroken=true&order=clickcount&reverse=true&limit=12&tag=\(tag)"
        }
        let url = URL(string: urlString)!
        let (data, response) = try await session.data(from: url)
        try validate(response)
        let stations = try JSONDecoder().decode([RBStation].self, from: data)
        return stations.compactMap { s in
            guard let name = s.name, !name.isEmpty else { return nil }
            let stream = s.url_resolved ?? s.url
            guard let stream, !stream.isEmpty else { return nil }
            let codec = (s.codec ?? "").lowercased()
            guard ["mp3", "mpeg", "aac", "aac+", "flac", "ogg", "vorbis"].contains(codec) else { return nil }
            let detail = [s.country, s.bitrate.map { "\($0) kbps" }].compactMap { $0 }.joined(separator: "  |  ")
            return RadioStation(name: name, streamURL: stream, detail: detail)
        }
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw URLError(.badServerResponse) }
    }

    private func distanceMiles(lat1: Double, lon1: Double, lat2: Double, lon2: Double) -> Double {
        let r = 3958.7613
        let p1 = lat1 * .pi / 180, p2 = lat2 * .pi / 180
        let dp = (lat2 - lat1) * .pi / 180, dl = (lon2 - lon1) * .pi / 180
        let a = sin(dp/2)*sin(dp/2) + cos(p1)*cos(p2)*sin(dl/2)*sin(dl/2)
        return 2 * r * atan2(sqrt(a), sqrt(1-a))
    }

    private func direction(_ degrees: Double) -> String {
        let dirs = ["N","NE","E","SE","S","SW","W","NW"]
        return dirs[Int((degrees + 22.5) / 45.0) % 8]
    }

    private func condition(_ code: Int) -> String {
        switch code { case 0: return "Clear"; case 1: return "Mostly clear"; case 2: return "Partly cloudy"; case 3: return "Overcast"; case 45,48: return "Fog"; case 51...57: return "Drizzle"; case 61...65: return "Rain"; case 66,67: return "Freezing rain"; case 71...77: return "Snow"; case 80...82: return "Showers"; case 85,86: return "Snow showers"; case 95: return "Thunderstorm"; case 96,99: return "Storms, hail"; default: return "Unknown" }
    }
}

private struct GeoResponse: Decodable { let results: [GeoResult] }
private struct GeoResult: Decodable { let name: String; let latitude: Double; let longitude: Double; let admin1: String? }
private struct OpenMeteoResponse: Decodable { let current: Current; let daily: Daily; let hourly: Hourly }
private struct Current: Decodable { let temperature_2m: Double; let apparent_temperature: Double; let relative_humidity_2m: Double; let wind_speed_10m: Double; let wind_direction_10m: Double; let weather_code: Int; enum CodingKeys: String, CodingKey { case temperature_2m, apparent_temperature, relative_humidity_2m, wind_speed_10m, wind_direction_10m, weather_code } }
private struct Daily: Decodable { let time: [String]; let weather_code: [Int]; let temperature_2m_max: [Double]; let temperature_2m_min: [Double]; let precipitation_probability_max: [Int]; enum CodingKeys: String, CodingKey { case time, weather_code, temperature_2m_max, temperature_2m_min, precipitation_probability_max } }
private struct Hourly: Decodable { let time: [String]; let temperature_2m: [Double]; let precipitation_probability: [Int]; enum CodingKeys: String, CodingKey { case time, temperature_2m, precipitation_probability } }
private struct WXStation: Decodable { let latitude: Double?; let longitude: Double?; let callsign: String?; let city: String?; let frequency: String?; let feeds: [WXFeed]? }
private struct WXFeed: Decodable { let stream_url: String? }
private struct RBStation: Decodable { let name: String?; let url: String?; let url_resolved: String?; let codec: String?; let country: String?; let bitrate: Int? }
