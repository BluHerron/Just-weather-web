import SwiftUI

@main
struct Just_Weather_IPhoneApp: App {
    @StateObject private var store = AppStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .task { await store.start() }
        }
    }
}
