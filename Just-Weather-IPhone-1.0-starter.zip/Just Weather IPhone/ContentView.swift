import SwiftUI
import MapKit

struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @State private var tab = 0

    var body: some View {
        TabView(selection: $tab) {
            WeatherHomeView().tabItem { Label("Weather", systemImage: "cloud.sun.fill") }.tag(0)
            RadarView().tabItem { Label("Radar", systemImage: "dot.radiowaves.left.and.right") }.tag(1)
            NOAAView().tabItem { Label("NOAA", systemImage: "radio.fill") }.tag(2)
            RadioView().tabItem { Label("Radio", systemImage: "antenna.radiowaves.left.and.right") }.tag(3)
            SettingsView().tabItem { Label("Settings", systemImage: "gearshape.fill") }.tag(4)
        }
        .tint(.blue)
    }
}

struct WeatherHomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingSearch = false
    @State private var showingFavorites = false
    @State private var query = ""
    @State private var results: [WeatherLocation] = []

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    if let w = store.weather {
                        VStack(spacing: 5) {
                            Text(w.location.name).font(.title2.weight(.semibold))
                            Text(Date(), style: .time).font(.subheadline).foregroundStyle(.secondary)
                            Text("\(Int(w.temperature.rounded()))°") .font(.system(size: 84, weight: .bold, design: .rounded))
                            Text(w.condition).font(.title3.weight(.medium))
                            Text("Feels like \(Int(w.apparentTemperature.rounded()))°  •  Humidity \(Int(w.humidity.rounded()))%")
                                .foregroundStyle(.secondary)
                            Text("Wind \(Int(w.windSpeed.rounded())) \(store.windKmh ? "km/h" : "mph") \(w.windDirection)").foregroundStyle(.secondary)
                        }.frame(maxWidth: .infinity).padding(.top, 12)

                        HStack(spacing: 12) {
                            Button { store.addFavorite(w.location) } label: { Label(store.favorites.contains(w.location) ? "Favorited" : "Favorite", systemImage: store.favorites.contains(w.location) ? "star.fill" : "star") }
                                .buttonStyle(.borderedProminent)
                            Button { showingFavorites = true } label: { Label("Favorites", systemImage: "list.star") }.buttonStyle(.bordered)
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            Text("7-Day Forecast").font(.headline)
                            ForEach(w.days.prefix(7)) { day in
                                ForecastRow(day: day, units: store.units)
                            }
                        }.padding(.horizontal)
                    } else if store.isLoading {
                        ProgressView("Loading weather…").padding(.top, 80)
                    } else {
                        ContentUnavailableView("Choose a location", systemImage: "location.magnifyingglass", description: Text("Search for a city or allow location access."))
                    }
                    if let error = store.errorMessage { Text(error).font(.footnote).foregroundStyle(.red).padding(.horizontal) }
                }
            }
            .refreshable { await store.refresh() }
            .navigationTitle("Just Weather")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { Button { showingSearch = true } label: { Image(systemName: "magnifyingglass") } }
                ToolbarItem(placement: .topBarLeading) { Button { showingFavorites = true } label: { Image(systemName: "star") } }
            }
            .sheet(isPresented: $showingSearch) {
                LocationSearchView()
            }
            .sheet(isPresented: $showingFavorites) {
                FavoritesView()
            }
        }
    }
}

struct ForecastRow: View {
    let day: ForecastDay; let units: WeatherUnits
    var body: some View {
        HStack {
            Text(day.date, format: .dateTime.weekday(.abbreviated)).frame(width: 42, alignment: .leading)
            Text(day.condition).frame(maxWidth: .infinity, alignment: .leading).foregroundStyle(.secondary)
            Text("\(Int(day.high.rounded()))° / \(Int(day.low.rounded()))°")
            Text("\(day.precipitationProbability)%").frame(width: 45, alignment: .trailing).foregroundStyle(.secondary)
        }.padding(.vertical, 6)
    }
}

struct LocationSearchView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var results: [WeatherLocation] = []
    var body: some View {
        NavigationStack {
            List(results) { location in
                Button { Task { await store.select(location); dismiss() } } label: { Label(location.name, systemImage: "location") }
            }
            .searchable(text: $query, prompt: "City or ZIP code")
            .onChange(of: query) { _, value in
                guard value.count >= 2 else { results = []; return }
                Task { results = (try? await store.searchLocations(value)) ?? [] }
            }
            .navigationTitle("Choose Location")
        }
    }
}

struct FavoritesView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.favorites) { location in
                    Button { Task { await store.select(location); dismiss() } } label: {
                        Label(location.name, systemImage: "star.fill")
                    }
                }.onDelete { indexSet in indexSet.map { store.favorites[$0] }.forEach(store.removeFavorite) }
            }.navigationTitle("Favorites").toolbar { EditButton() }
        }
    }
}

struct NOAAView: View {
    @EnvironmentObject private var store: AppStore
    var body: some View {
        NavigationStack {
            List {
                if let location = store.selectedLocation { Section("Nearest to \(location.name)") { } }
                ForEach(store.noaaStations) { station in
                    Button { store.play(url: station.streamURL) } label: {
                        VStack(alignment: .leading) { Text(station.name); Text("\(station.frequency.isEmpty ? "NOAA Weather Radio" : station.frequency + " MHz")  •  \(station.distanceMiles) mi away").font(.caption).foregroundStyle(.secondary) }
                    }
                }
            }
            .overlay { if store.isFindingNOAA { ProgressView("Finding nearby NOAA stations…") } }
            .navigationTitle("NOAA Weather Radio")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Find") { Task { await store.findNOAA() } }.disabled(store.selectedLocation == nil) } }
            .safeAreaInset(edge: .bottom) { if store.radioPlaying { HStack { Text("Playing NOAA / radio").font(.footnote); Spacer(); Button("Stop") { store.stopRadio() } }.padding().background(.thinMaterial) } }
            .task { if store.noaaStations.isEmpty { await store.findNOAA() } }
        }
    }
}

struct RadioView: View {
    @EnvironmentObject private var store: AppStore
    let categories = ["local-radio", "rock", "country", "jazz", "classical", "indie", "news"]
    var body: some View {
        NavigationStack {
            List {
                Section("Browse") {
                    ForEach(categories, id: \.self) { category in
                        Button(category.replacingOccurrences(of: "-", with: " ").capitalized) { Task { await store.findRadio(category: category) } }
                    }
                }
                if !store.radioStations.isEmpty {
                    Section(store.radioCategory.capitalized) {
                        ForEach(store.radioStations) { station in
                            Button { store.play(url: station.streamURL) } label: { VStack(alignment: .leading) { Text(station.name); if !station.detail.isEmpty { Text(station.detail).font(.caption).foregroundStyle(.secondary) } } }
                        }
                    }
                }
            }
            .overlay { if store.isFindingRadio { ProgressView("Finding stations…") } }
            .navigationTitle("Internet Radio")
            .safeAreaInset(edge: .bottom) { if store.radioPlaying { HStack { Image(systemName: "waveform"); Text("Playing"); Spacer(); Button("Stop") { store.stopRadio() } }.padding().background(.thinMaterial) } }
        }
    }
}

struct RadarView: View {
    @EnvironmentObject private var store: AppStore
    var body: some View {
        NavigationStack {
            Group {
                if let location = store.selectedLocation {
                    RadarMapView(center: CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude), miles: store.radarMiles)
                        .ignoresSafeArea(edges: .bottom)
                } else { ContentUnavailableView("Choose a location", systemImage: "map") }
            }
            .navigationTitle("Rain Radar")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Menu { Picker("Range", selection: $store.radarMiles) { ForEach([10,25,50,100], id: \.self) { Text("\($0) miles").tag($0) } } } label: { Image(systemName: "slider.horizontal.3") } } }
        }
    }
}

struct RadarMapView: UIViewRepresentable {
    let center: CLLocationCoordinate2D; let miles: Int
    func makeUIView(context: Context) -> MKMapView { let map = MKMapView(); map.mapType = .mutedStandard; return map }
    func updateUIView(_ map: MKMapView, context: Context) {
        let meters = Double(miles) * 1609.344
        map.setRegion(MKCoordinateRegion(center: center, latitudinalMeters: meters, longitudinalMeters: meters), animated: false)
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    var body: some View {
        NavigationStack {
            Form {
                Section("Units") {
                    Picker("Temperature", selection: $store.units) { Text("Fahrenheit").tag(WeatherUnits.fahrenheit); Text("Celsius").tag(WeatherUnits.celsius) }.onChange(of: store.units) { _, _ in store.savePreferences(); Task { await store.refresh() } }
                    Toggle("Wind in km/h", isOn: $store.windKmh).onChange(of: store.windKmh) { _, _ in store.savePreferences(); Task { await store.refresh() } }
                }
                Section("Radar") {
                    Toggle("Show radar", isOn: $store.radarEnabled).onChange(of: store.radarEnabled) { _, _ in store.savePreferences() }
                    Picker("Radar range", selection: $store.radarMiles) { ForEach([10,25,50,100], id: \.self) { Text("\($0) miles").tag($0) } }.onChange(of: store.radarMiles) { _, _ in store.savePreferences() }
                }
                Section("Display") {
                    Toggle("24-hour clock", isOn: $store.clock24).onChange(of: store.clock24) { _, _ in store.savePreferences() }
                    Toggle("Dim interface", isOn: $store.dimEnabled).onChange(of: store.dimEnabled) { _, _ in store.savePreferences() }
                }
                Section("About") { Text("Just Weather IPhone 1.0"); Text("Weather data: Open-Meteo • Radar: MapKit foundation • Radio directories: Radio Browser / WXIndex") .font(.footnote).foregroundStyle(.secondary) }
            }.navigationTitle("Settings")
        }
    }
}
