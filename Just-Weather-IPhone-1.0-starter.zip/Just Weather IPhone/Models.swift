import Foundation

struct WeatherLocation: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var name: String
    var latitude: Double
    var longitude: Double
}

struct WeatherSnapshot: Codable {
    var location: WeatherLocation
    var temperature: Double
    var apparentTemperature: Double
    var humidity: Double
    var windSpeed: Double
    var windDirection: String
    var condition: String
    var days: [ForecastDay]
    var hourly: [HourlyPoint]
    var updatedAt: Date
}

struct ForecastDay: Codable, Identifiable, Hashable {
    var id = UUID()
    var date: Date
    var high: Double
    var low: Double
    var precipitationProbability: Int
    var condition: String
}

struct HourlyPoint: Codable, Identifiable, Hashable {
    var id = UUID()
    var date: Date
    var temperature: Double
    var precipitationProbability: Int
}

struct NOAAStation: Identifiable, Hashable {
    var id: String { streamURL }
    var name: String
    var callSign: String
    var city: String
    var frequency: String
    var streamURL: String
    var distanceMiles: Int
}

struct RadioStation: Identifiable, Hashable {
    var id: String { streamURL }
    var name: String
    var streamURL: String
    var detail: String
}

enum WeatherUnits: String, CaseIterable, Codable {
    case fahrenheit
    case celsius

    var symbol: String { self == .fahrenheit ? "°F" : "°C" }
}
